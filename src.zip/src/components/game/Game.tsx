import React from 'react';

import { MainMenu } from '../mainmenu/MainMenu';



export class Game extends React.Component<{}, {}> {

    render():JSX.Element {
        return <MainMenu />
    }
}
