import React from 'react';
import { connect } from 'react-redux';

import './MainMenu.css';
import { MainMenuButton } from '../mainmenubutton/MainMenuButton';
import { MainGameStateTypes, GameState } from '../../models';
import { getGameMode, getState } from '../../redux/selectors';
import { startNewGame } from '../../redux/actions';
// import { store } from '../../redux/store';



interface GameModeProps {
    startNewGame?: () => void,
    gameMode?: MainGameStateTypes,
    getState?: GameState
}

export class MainMenu extends React.Component<GameModeProps, {}> {

    canContinue:boolean = false;

    getGameMode() {
        // store.dispatch(startNewGame());
        console.log(this.props);
        if (this.props && this.props.startNewGame)
            this.props.startNewGame();
    }

    render():JSX.Element {
        
        return (
            <React.Fragment>
                <div className="mainmenu-bg">
                    <div className="mainmenu-content">
                        <h1 className="mainmenu-gametitle">FURY ROAD</h1>
                        <div className="buttons-div">
                            <MainMenuButton 
                                title="Kontynuuj"
                                active={ this.canContinue }
                                onClick={ () => console.log("CONTINUE!") }
                            />
                            <MainMenuButton
                                title="Nowa gra"
                                active={true}
                                onClick={ () => {
                                    if (this.props.startNewGame)
                                    this.props.startNewGame()
                                } }
                            />
                            <MainMenuButton
                                title="Śmietnisko"
                                active={true}
                                onClick={ () => console.log("JUNKJARD!") }
                            />
                            <MainMenuButton
                                title="Ustawienia"
                                active={true}
                                onClick={ () => console.log("SETTINGS!") }  // this.goToSettings()
                            />
                        </div>
                    </div>                    
                </div>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state:GameState) => ({
    gameMode:  getGameMode(state),
    getState:  getState(state)
 });
 
const mapDispatchToProps = (dispatch:any) => ({
    startNewGame: () => dispatch(startNewGame()),
});

export default connect(mapStateToProps, mapDispatchToProps)(MainMenu);
