export interface MainMenuButtonModel {
    title:      string,
    active:     boolean,
    onClick:    () => void
}
