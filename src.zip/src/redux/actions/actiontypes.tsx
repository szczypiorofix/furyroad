// Action types

export enum ActionTypes {
    MAIN_MENU_BUTTON_CLICKED = 'Main_Menu_Button_Clicked'
}
