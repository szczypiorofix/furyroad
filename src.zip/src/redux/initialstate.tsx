
import { GameState, MainGameStateTypes } from '../models';

const initialState: GameState = {
    mode: MainGameStateTypes.MAIN_MENU,
    stats: {
        fuel: 10,
        water: 10
    }
}

export default initialState;
