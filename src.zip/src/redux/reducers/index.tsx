// import { combineReducers } from 'redux'

// import { visibilityFilter, todoApp } from './reducer';
// import mainMenuButtonClickedReducer from './mainmenureducer';


// const myCombinedReducers = combineReducers({
//     action1: mainMenuButtonClickedReducer
// });


// export * from './reducer';

// export default myCombinedReducers;

export * from './mainmenureducer';