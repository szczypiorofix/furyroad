import { Reducer } from 'redux';
import { MainMenuModeAction, MainMenuMode } from '../actions';
import initialState from '../initialstate';
import { GameState, MainGameStateTypes } from '../../models';

const mainMenuButtonClickedReducer: Reducer<GameState, MainMenuModeAction> = ( state: GameState = initialState, action: MainMenuModeAction): GameState => {
    switch (action.type) {
        case MainMenuMode.MMM_NEWGAME:            
            return {...state, mode: MainGameStateTypes.NEW_GAME};
        default:
            return state;
    }
}

export default mainMenuButtonClickedReducer;
