 import { MainGameStateTypes, GameState } from '../../models';


export const getGameMode = (state: GameState): MainGameStateTypes => state.mode;

export const getState = (state: GameState): GameState => state;
