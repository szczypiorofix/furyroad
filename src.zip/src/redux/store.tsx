import { createStore, applyMiddleware } from 'redux';
import { createLogger } from 'redux-logger';
import { GameState } from '../models';
import mainMenuButtonClickedReducer from './reducers/mainmenureducer';
import initialState from './initialstate';


let middleware: any[] = [];
if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
    const logger = createLogger({
        diff: true,
    });
    middleware = [...middleware, logger];
}

export const store = createStore<GameState, any, any, any>(mainMenuButtonClickedReducer, initialState, applyMiddleware(...middleware));
store.subscribe(() => {
    store.getState()
});
